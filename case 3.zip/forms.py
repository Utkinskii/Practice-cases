from django import forms


class GreetingForm(forms.Form):
    name = forms.CharField(
        max_length=100,
        min_length=1,
        label='Ваше имя',
        widget=forms.TextInput(attrs={
            'placeholder': 'Введите ваше имя...',
            'class': 'name-input',
            'autofocus': True,
        }),
        error_messages={
            'required': 'Пожалуйста, введите ваше имя.',
            'min_length': 'Имя не может быть пустым.',
            'max_length': 'Имя не должно превышать 100 символов.',
        }
    )

    def clean_name(self):
        name = self.cleaned_data.get('name', '').strip()
        if not name:
            raise forms.ValidationError('Пожалуйста, введите ваше имя.')
        if not any(char.isalpha() for char in name):
            raise forms.ValidationError('Имя должно содержать хотя бы одну букву.')
        return name
