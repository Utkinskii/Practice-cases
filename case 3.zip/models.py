from django.db import models


class UserGreeting(models.Model):
    """Model to store user names submitted through the greeting form."""
    name = models.CharField(max_length=100)
    created_at = models.DateTimeField(auto_now_add=True)

    class Meta:
        verbose_name = 'Приветствие'
        verbose_name_plural = 'Приветствия'
        ordering = ['-created_at']

    def __str__(self):
        return self.name
