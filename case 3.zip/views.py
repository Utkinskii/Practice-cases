from django.shortcuts import render, redirect
from django.contrib import messages
from .forms import GreetingForm
from .models import UserGreeting


def index(request):
    """
    Main view: handles both GET (show form) and POST (process form).
    - Validates the submitted name
    - Saves valid names to the database
    - Displays personalized greeting or error messages
    """
    greeting_name = None
    form = GreetingForm()

    if request.method == 'POST':
        form = GreetingForm(request.POST)
        if form.is_valid():
            name = form.cleaned_data['name']
            # Save name to database
            UserGreeting.objects.create(name=name)
            greeting_name = name
            # Reset form after successful submission
            form = GreetingForm()
        else:
            messages.error(request, 'Пожалуйста, исправьте ошибки в форме.')

    # Fetch recent greetings to display history (last 5)
    recent_greetings = UserGreeting.objects.all()[:5]

    context = {
        'form': form,
        'greeting_name': greeting_name,
        'recent_greetings': recent_greetings,
    }
    return render(request, 'greeting_app/index.html', context)
