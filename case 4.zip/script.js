const num1Input = document.getElementById('num1');
const num2Input = document.getElementById('num2');
const resultBox = document.getElementById('result');

function getNumbers() {
  const value1 = num1Input.value.trim();
  const value2 = num2Input.value.trim();

  if (value1 === '' || value2 === '') {
    showError('Ошибка: заполните оба поля числами.');
    return null;
  }

  const number1 = Number(value1);
  const number2 = Number(value2);

  if (Number.isNaN(number1) || Number.isNaN(number2)) {
    showError('Ошибка: в инпуты нужно вводить только цифры.');
    return null;
  }

  return { number1, number2 };
}

function showError(message) {
  resultBox.textContent = message;
  resultBox.classList.remove('success');
  resultBox.classList.add('error');
}

function showResult(message) {
  resultBox.textContent = message;
  resultBox.classList.remove('error');
  resultBox.classList.add('success');
}

function sum() {
  const numbers = getNumbers();
  if (!numbers) return;
  const result = numbers.number1 + numbers.number2;
  showResult(`Результат: ${result}`);
}

function difference() {
  const numbers = getNumbers();
  if (!numbers) return;
  const result = numbers.number1 - numbers.number2;
  showResult(`Результат: ${result}`);
}

function multiply() {
  const numbers = getNumbers();
  if (!numbers) return;
  const result = numbers.number1 * numbers.number2;
  showResult(`Результат: ${result}`);
}

function divide() {
  const numbers = getNumbers();
  if (!numbers) return;

  if (numbers.number2 === 0) {
    showError('Ошибка: деление на ноль невозможно.');
    return;
  }

  const result = numbers.number1 / numbers.number2;
  showResult(`Результат: ${result}`);
}

document.getElementById('sumBtn').addEventListener('click', sum);
document.getElementById('diffBtn').addEventListener('click', difference);
document.getElementById('multBtn').addEventListener('click', multiply);
document.getElementById('divBtn').addEventListener('click', divide);
