const plusBtn = document.getElementById("plusBtn");
const minusBtn = document.getElementById("minusBtn");
const resultEl = document.getElementById("result");
const messageEl = document.getElementById("message");

let value = 0;

function updateUI() {
  resultEl.textContent = String(value);

  if (value > 0) {
    resultEl.style.background = "yellow";
  } else if (value < 0) {
    resultEl.style.background = "green";
  } else {
    resultEl.style.background = "red";
  }

  plusBtn.disabled = value >= 10;
  minusBtn.disabled = value <= -10;

  if (value === 10 || value === -10) {
    messageEl.textContent = "вы достигли экстремального значения";
  } else {
    messageEl.textContent = "";
  }
}

plusBtn.addEventListener("click", () => {
  if (value < 10) value += 1;
  updateUI();
});

minusBtn.addEventListener("click", () => {
  if (value > -10) value -= 1;
  updateUI();
});

updateUI();
